(async function() {
  console.log("🟡 content.js iniciado");

  const SENHA_PADRAO = "111112";
  const camposDigitados = new WeakSet();
  let registroJaClicado = false;
  function gerarTelefoneBR() {
    const ddds = ['11', '21', '31', '41', '51', '61', '71', '81', '85', '91'];
    const ddd = ddds[Math.floor(Math.random() * ddds.length)];
    const numero = '9' + Array.from({ length: 8 }, () => Math.floor(Math.random() * 10)).join('');
    return ddd + numero;  // ex: 81987799814
  }
  
  function verificarErro403EAtualizar() {
    function contemErro403() {
      const h1 = document.querySelector("h1");
      const titulo = document.title?.toLowerCase() || "";
      const corpo = document.body?.innerText?.toLowerCase() || "";
  
      return (
        (h1 && h1.textContent.includes("403")) ||
        titulo.includes("403 error") ||
        corpo.includes("the request could not be satisfied")
      );
    }
  
    if (contemErro403()) {
      console.warn("🚫 Erro 403 (CloudFront) detectado! Atualizando página em 2s...");
      setTimeout(() => {
        location.reload();
      }, 2000);
      return;
    }
  
    // Caso o erro apareça depois (página SPA ou carregamento assíncrono)
    const observer = new MutationObserver(() => {
      if (contemErro403()) {
        console.warn("🚫 Erro 403 detectado por mutação! Atualizando página...");
        location.reload();
      }
    });
  
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  
    console.log("👁️ Monitoramento de erro 403 ativado.");
  }
  

  function gerarDadosAleatorios() {
    return {
      account: Array.from({ length: Math.floor(Math.random() * 7) + 6 }, () => {
        const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        return chars[Math.floor(Math.random() * chars.length)];
      }).join(""),
      realName: ["João Silva", "Maria Souza", "Carlos Lima", "Ana Paula"][Math.floor(Math.random()*4)],
      phone: gerarTelefoneBR()
    };
  }
  

  let confirmarAposTecladoExecutado = false;

  async function clicarBotaoConfirmarAposTeclado() {
    if (confirmarAposTecladoExecutado) return;
  
    // 🔎 Tenta encontrar imediatamente o botão "Confirmar"
    const botaoExistente = [...document.querySelectorAll('button')]
      .find(btn =>
        btn.textContent.trim().toLowerCase() === "confirmar" &&
        btn.offsetParent !== null &&
        !btn.classList.contains("ui-button--loading")
      );
  
    if (botaoExistente) {
      botaoExistente.focus();
      botaoExistente.dispatchEvent(new Event('mousedown', { bubbles: true }));
      botaoExistente.dispatchEvent(new Event('mouseup', { bubbles: true }));
      botaoExistente.dispatchEvent(new Event('click', { bubbles: true }));
      console.log("✅ Botão 'Confirmar' clicado diretamente.");
      confirmarAposTecladoExecutado = true;
      return;
    }
  
    // 🔄 Se não encontrou imediatamente, espera aparecer
    const esperarBotaoConfirmar = () => new Promise(resolve => {
      const timeout = setTimeout(() => {
        observer.disconnect();
        resolve(null);
      }, 7000);
  
      const observer = new MutationObserver(() => {
        const botaoConfirmar = [...document.querySelectorAll('button')]
          .find(btn =>
            btn.textContent.trim().toLowerCase() === "confirmar" &&
            btn.offsetParent !== null &&
            !btn.classList.contains("ui-button--loading")
          );
  
        if (botaoConfirmar) {
          clearTimeout(timeout);
          observer.disconnect();
          resolve(botaoConfirmar);
        }
      });
  
      observer.observe(document.body, { childList: true, subtree: true });
    });
  
    const botao = await esperarBotaoConfirmar();
  
    if (botao) {
      botao.focus();
      botao.dispatchEvent(new Event('mousedown', { bubbles: true }));
      botao.dispatchEvent(new Event('mouseup', { bubbles: true }));
      botao.dispatchEvent(new Event('click', { bubbles: true }));
      console.log("✅ Botão 'Confirmar' clicado após teclado virtual.");
      confirmarAposTecladoExecutado = true;
    } else {
      console.log("⚠️ Botão 'Confirmar' não apareceu ou estava carregando.");
    }
  }
  

  

  async function ativarFocoCampoSenha() {
    console.log("🎯 Ativando foco no campo de senha...");
  
    const primeiroBotao = document.querySelector("li.ui-password-input__item");
    if (primeiroBotao) {
      try {
        primeiroBotao.click();
        primeiroBotao.focus();
        console.log("✅ Clique real e foco aplicado no primeiro <li> do teclado virtual");
        
        await new Promise(r => setTimeout(r, 300)); 
      } catch (e) {
        console.warn("⚠️ Erro ao simular clique no <li>:", e);
      }
    } else {
      console.log("❌ Nenhum botão <li> encontrado para simular clique");
    }
  }

  async function digitarInstantaneo(numeroString) {
    console.log(`⚡ MODO INSTANTÂNEO - Digitando: "${numeroString}"`);

    const tecladosVisiveis = [...document.querySelectorAll('.ui-number-keyboard')]
      .filter(teclado => {
        const estilo = window.getComputedStyle(teclado);
        return estilo.display !== 'none' && estilo.visibility !== 'hidden' && estilo.opacity !== '0';
      });

    if (tecladosVisiveis.length === 0) {
      console.error("❌ Nenhum teclado visível!");
      return;
    }

    const tecladoAtivo = tecladosVisiveis[0];
    const mapaTeclas = new Map();

    tecladoAtivo.querySelectorAll('.ui-number-keyboard-key').forEach(tecla => {
      const texto = tecla.textContent.trim();
      if (texto) mapaTeclas.set(texto, tecla);
    });

    for (let i = 0; i < numeroString.length; i++) {
      const digito = numeroString[i];
      const tecla = mapaTeclas.get(digito);

      if (tecla) {
        tecla.click();
        tecla.dispatchEvent(new Event('mousedown', { bubbles: true }));
        tecla.dispatchEvent(new Event('mouseup', { bubbles: true }));

        console.log(`⚡ ${i + 1}/${numeroString.length}: "${digito}"`);
        await new Promise(r => setTimeout(r, 80));
      } else {
        console.error(`❌ Tecla "${digito}" NÃO encontrada no mapa`);
      }
    }

    const campoSenha = document.querySelector('ul.ui-password-input__security');
    if (campoSenha) {
      let tentativas = 0;
      while (true) {
        const visiveis = campoSenha.querySelectorAll('li.ui-password-input__item i[style*="visibility: visible"]').length;
        if (visiveis >= numeroString.length) break;
        if (++tentativas > 3) {
          console.warn("⚠️ Tentativas máximas de correção excedidas");
          break;
        }

        const ultimoDigito = numeroString[numeroString.length - 1];
        const tecla = mapaTeclas.get(ultimoDigito);
        if (tecla) {
          console.log(`🔁 Corrigindo última tecla: "${ultimoDigito}"`);
          tecla.click();
          tecla.dispatchEvent(new Event('mousedown', { bubbles: true }));
          tecla.dispatchEvent(new Event('mouseup', { bubbles: true }));
          await new Promise(r => setTimeout(r, 100));
        }
      }
    }

    console.log(`⚡ CONCLUÍDO: "${numeroString}"`);
  }

  async function digitarSenhasSeparadas(senha1, senha2) {
    const teclados = [...document.querySelectorAll('.ui-number-keyboard')];
    if (teclados.length < 2) {
      console.warn("⚠️ Menos de 2 teclados encontrados!");
      await digitarInstantaneo(senha1);
      return;
    }

    const [teclado1, teclado2] = teclados;

    function mostrarTeclado(tecladoParaMostrar) {
      teclados.forEach(t => {
        t.style.display = (t === tecladoParaMostrar) ? 'block' : 'none';
      });
    }

    console.log("🔄 Mostrando teclado 1 e digitando senha 1");
    mostrarTeclado(teclado1);
    await digitarInstantaneo(senha1);

    await new Promise(r => setTimeout(r, 300));

    console.log("🔄 Mostrando teclado 2 e digitando senha 2");
    mostrarTeclado(teclado2);
    await digitarInstantaneo(senha2);

    teclados.forEach(t => t.style.display = 'none');
    console.log("✅ Senhas digitadas e teclados escondidos");
  }

  async function automatizarDigitacao() {
    console.log("🤖 Iniciando automatização de digitação...");
    await ativarFocoCampoSenha();
    await new Promise(r => setTimeout(r, 500));

    const tecladosVisiveis = [...document.querySelectorAll('.ui-number-keyboard')]
      .filter(teclado => {
        const estilo = window.getComputedStyle(teclado);
        return estilo.display !== 'none' && estilo.visibility !== 'hidden' && estilo.opacity !== '0';
      });

    if (tecladosVisiveis.length === 0) {
      console.warn("⚠️ Nenhum teclado visível!");
      return;
    }

    try {
      await digitarSenhasSeparadas(SENHA_PADRAO, SENHA_PADRAO);
      console.log("🎉 Automatização COMPLETA!");
      // await clicarBotaoConfirmarAposTeclado(); // <-- aqui
      // await aguardarPopupEclicarAdicionar();
      // await aguardarEClicarProximo(); 
    } catch (error) {
      console.error("❌ Erro:", error);
    }
  }
  let registroInicialClicado = false;

  async function clicarBotaoRegistroInicial() {
    if (registroInicialClicado) return;
  
    const spanRegistro = [...document.querySelectorAll('span')]
      .find(span => span.textContent.trim() === "Registro" && span.offsetParent !== null);
  
    if (spanRegistro) {
      spanRegistro.click();
      registroInicialClicado = true;
      console.log("✅ <span> 'Registro' clicado!");
      await new Promise(r => setTimeout(r, 1000));
    } else {
      console.log("⚠️ <span> 'Registro' não encontrado ou invisível");
    }
  }
  
  

  async function preencherCampos() {
    const dados = gerarDadosAleatorios();

    // const accountInput = document.querySelector('input[data-input-name="account"]');
    // const userpassInput = document.querySelector('input[data-input-name="userpass"]');
    // const confirmPasswordInput = document.querySelector('input[data-input-name="confirmPassword"]');
    // const realNameInput = document.querySelector('input[data-input-name="realName"]');
    // const phoneInput = document.querySelector('input[data-input-name="phone"]');

    // const accountInputTel = document.querySelector('input[data-input-name="account"][type="tel"]');
    // if (accountInputTel && !accountInputTel.value) {
    //   accountInputTel.value = dados.phone;
    //   accountInputTel.dispatchEvent(new Event('input', { bubbles: true }));
    //   console.log("✅ Preencheu account (tel):", dados.phone);
    // }
  
    // if (accountInput && !accountInput.value) {
    //   accountInput.value = dados.account;
    //   accountInput.dispatchEvent(new Event('input', { bubbles: true }));
    //   console.log("✅ Preencheu account:", dados.account);
    // }
  
    // if (realNameInput && !realNameInput.value) {
    //   realNameInput.value = dados.realName;
    //   realNameInput.dispatchEvent(new Event('input', { bubbles: true }));
    //   console.log("✅ Preencheu realName:", dados.realName);
    // }
  
    // if (phoneInput && !phoneInput.value && !camposDigitados.has(phoneInput)) {
    //   phoneInput.value = dados.phone;
    //   phoneInput.dispatchEvent(new Event('input', { bubbles: true }));
    //   camposDigitados.add(phoneInput);
    //   console.log("✅ Preencheu telefone:", dados.phone);
    // }

    const ulSenha = document.querySelector('ul.ui-password-input__security');
    if (ulSenha) {
      const itens = ulSenha.querySelectorAll('li.ui-password-input__item i[style*="visibility: hidden"]');
      const digitado = [...itens].some(i => i.style.visibility !== 'hidden');

      if (!digitado && !camposDigitados.has(ulSenha)) {
        camposDigitados.add(ulSenha);

        if (document.querySelector('.ui-number-keyboard')) {
          console.log("⌨️ Teclado detectado - iniciando automatização RÁPIDA...");
          await automatizarDigitacao();
        }
        //  else if (userpassInput && !userpassInput.value) {
        //   userpassInput.value = dados.userpass;
        //   userpassInput.dispatchEvent(new Event('input', { bubbles: true }));
        //   console.log("✅ Preencheu userpass direto:", dados.userpass);
        // }
      }
     } 
    // else {
    //   if (userpassInput && !userpassInput.value) {
    //     userpassInput.value = dados.userpass;
    //     userpassInput.dispatchEvent(new Event('input', { bubbles: true }));
    //     console.log("✅ Preencheu userpass direto:", dados.userpass);
    //   }
    //   if (confirmPasswordInput && !confirmPasswordInput.value) {
    //     confirmPasswordInput.value = dados.confirmPassword;
    //     confirmPasswordInput.dispatchEvent(new Event('input', { bubbles: true }));
    //     console.log("✅ Preencheu confirmPassword direto:", dados.confirmPassword);
    //   }
    // }
  }

  function fecharAnunciosECancelar() {
    const btnFecharSVG = document.querySelector('svg use[xlink\\:href="#ui-close-059120"]');
    if (btnFecharSVG) {
      let btn = btnFecharSVG.closest('button, div, span');
      if (btn) {
        btn.click();
        console.log("❌ Fechou anúncio (SVG)");
      } else {
        btnFecharSVG.parentElement.click();
        console.log("❌ Fechou anúncio (SVG pai)");
      }
    }

    const btnCancelar = Array.from(document.querySelectorAll('button.ui-button'))
      .find(b => b.textContent.trim() === "Cancelar");
    if (btnCancelar) {
      btnCancelar.click();
      console.log("❌ Clicou em Cancelar");
    }
  }

  function lerSaldo() {
    const spans = document.querySelectorAll('div._currency-count_11c7r_90 span span[data-char]');
    if (!spans.length) return null;
    let valor = "";
    spans.forEach(s => valor += s.getAttribute("data-char"));
    return valor;
  }
  

  let salveImagemClicado = false;
  
  async function clicarBotoesDeRegistroSimples() {
    const btnRegistrar = document.querySelector('#insideRegisterSubmitClick');
  
    if (!btnRegistrar || btnRegistrar.offsetParent === null) {
      registroJaClicado = false; // reset se sumir
    }
  
    if (btnRegistrar && !registroJaClicado) {
      let tentativas = 0;
      while (btnRegistrar.classList.contains("ui-button--loading") && tentativas < 10) {
        console.log("⏳ Esperando botão REGISTRO sair do loading...");
        await new Promise(r => setTimeout(r, 300));
        tentativas++;
      }
  
      btnRegistrar.focus();
      btnRegistrar.dispatchEvent(new Event('mousedown', { bubbles: true }));
      btnRegistrar.dispatchEvent(new Event('mouseup', { bubbles: true }));
      btnRegistrar.dispatchEvent(new Event('click', { bubbles: true }));
      console.log("✅ Clique no botão REGISTRO enviado!");
      registroJaClicado = true;
    }
  
    // ➕ Após o registro, verificar se o botão "Salve a imagem e registre-se" aparece
    const btnSalvarImagem = [...document.querySelectorAll('button.ui-button')].find(b =>
      b.textContent.trim().includes("Salve a imagem")
    );
  
    if (!btnSalvarImagem || btnSalvarImagem.offsetParent === null) {
      salveImagemClicado = false; // reset se sumir
    }
  
    if (btnSalvarImagem && !salveImagemClicado) {
      btnSalvarImagem.focus();
      btnSalvarImagem.dispatchEvent(new Event('mousedown', { bubbles: true }));
      btnSalvarImagem.dispatchEvent(new Event('mouseup', { bubbles: true }));
      btnSalvarImagem.dispatchEvent(new Event('click', { bubbles: true }));
      console.log("✅ Clique no botão SALVAR IMAGEM enviado!");
      salveImagemClicado = true;
    }
  }

  let promocaoMissaoExecutado = false;

  async function irParaPromocaoEMissao() {
    if (promocaoMissaoExecutado) return;
  
    function esperarElementoVisivelComTexto(texto, timeout = 500000) {
      return new Promise(resolve => {
        const start = Date.now();
        const timer = setInterval(() => {
          const el = [...document.querySelectorAll('span, div, button, a')]
            .find(e => e.textContent.trim().toLowerCase() === texto.toLowerCase() && e.offsetParent !== null);
          if (el) {
            clearInterval(timer);
            resolve(el);
          } else if (Date.now() - start > timeout) {
            clearInterval(timer);
            resolve(null);
          }
        }, 200);
      });
    }
  
    const spanPromocao = await esperarElementoVisivelComTexto("promoção");
    if (spanPromocao) {
      spanPromocao.focus();
      spanPromocao.dispatchEvent(new Event('mousedown', { bubbles: true }));
      spanPromocao.dispatchEvent(new Event('mouseup', { bubbles: true }));
      spanPromocao.dispatchEvent(new Event('click', { bubbles: true }));
      console.log("✅ Clique em 'Promoção' enviado!");
      await new Promise(r => setTimeout(r, 800));
    } else {
      console.log("⚠️ 'Promoção' não encontrada.");
    }
  
    const spanMissao = await esperarElementoVisivelComTexto("missão");
    if (spanMissao) {
      spanMissao.focus();
      spanMissao.dispatchEvent(new Event('mousedown', { bubbles: true }));
      spanMissao.dispatchEvent(new Event('mouseup', { bubbles: true }));
      spanMissao.dispatchEvent(new Event('click', { bubbles: true }));
      console.log("✅ Clique em 'Missão' enviado!");
    } else {
      console.log("⚠️ 'Missão' não encontrada.");
    }
  
    promocaoMissaoExecutado = true;
  }
  


async function clicarReceberEProsseguir() {
  const btnReceber = document.getElementById('taskReceiveClick');
  if (btnReceber && btnReceber.offsetParent !== null) {
    console.log("✅ Clicando em 'Receber'");
    btnReceber.click();

    // Aguarda até 2s pra botão "Prosseguir" aparecer e clicar nele
    const esperarProsseguir = () => new Promise((resolve) => {
      const timeout = setTimeout(() => {
        observer.disconnect();
        resolve(false);
      }, 2000);

      const observer = new MutationObserver(() => {
        const btnProsseguir = [...document.querySelectorAll('button.ui-button.ui-button--primary.ui-button--large.ui-dialog__confirm')]
          .find(b => b.textContent.trim() === "Prosseguir" && b.offsetParent !== null);

        if (btnProsseguir) {
          clearTimeout(timeout);
          observer.disconnect();
          console.log("✅ Botão 'Prosseguir' detectado e clicando");
          btnProsseguir.click();
          resolve(true);
        }
      });

      observer.observe(document.body, { childList: true, subtree: true });
    });

    await esperarProsseguir();
  } else {
    console.log("⚠️ Botão 'Receber' não encontrado ou não visível");
  }
}

function monitorarPopupFechar() {
  const observerPopup = new MutationObserver(() => {
    const existeProsseguir = !!document.querySelector('button.ui-dialog__confirm span, button.ui-dialog__confirm');
    if (existeProsseguir) {
      console.log("🛑 'Prosseguir' detectado - ignorando fechamento.");
      return;
    }

    const existeRegistro = !!document.querySelector('button#insideRegisterSubmitClick');
    if (existeRegistro) {
      console.log("🛑 Botão 'Registro' detectado - ignorando fechamento.");
      return;
    }

    const botaoProximo = [...document.querySelectorAll('button')]
      .find(b =>
        b.textContent.trim().toLowerCase() === "próximo" &&
        b.offsetParent !== null
      );
    if (botaoProximo) {
      console.log("🛑 Botão 'Próximo' detectado - ignorando fechamento.");
      return;
    }

    const botaoConfirmarSaque = [...document.querySelectorAll('button')]
      .find(b =>
        b.offsetParent !== null &&
        (
          b.id === 'bindWithdrawAccountNextClick' ||
          b.textContent.trim().toLowerCase() === 'confirmar'
        )
      );
    if (botaoConfirmarSaque) {
      console.log("🛑 Botão 'Confirmar' (de saque) detectado - ignorando fechamento.");
      return;
    }


    // Tenta encontrar o botão padrão de fechar (ícone <i>)
    const iconeFechar = document.querySelector('i.ui-dialog-close-box__icon');
    if (iconeFechar && getComputedStyle(iconeFechar).display !== 'none') {
      console.log("❌ Fechando popup via <i.ui-dialog-close-box__icon>...");
      iconeFechar.click();
      return;
    }

    // Tenta encontrar o SVG diretamente (fallback extra)
    const svgFechar = [...document.querySelectorAll('svg use')]
      .find(use => use.getAttribute('xlink:href') === '#ui-close-059120');

    if (svgFechar) {
      const svg = svgFechar.closest('svg');
      if (svg) {
        const btn = svg.closest('button, div, span, i');
        if (btn && getComputedStyle(btn).display !== 'none') {
          console.log("❌ Fechando popup via <svg>...");
          btn.click();
        }
      }
    }
  });

  observerPopup.observe(document.body, {
    childList: true,
    subtree: true
  });

  console.log("👁️ Monitoramento de pop-up ativado...");
}

async function aguardarPopupEclicarAdicionar(timeoutMs = 7000) {
  console.log("⏳ Aguardando botão 'Adicionar' aparecer...");

  const encontrarBotaoAdicionar = () => {
    return [...document.querySelectorAll('span')]
      .find(el =>
        el.textContent.trim().toLowerCase() === "adicionar" &&
        el.offsetParent !== null
      );
  };

  const botaoInicial = encontrarBotaoAdicionar();
  if (botaoInicial) {
    botaoInicial.click();
    console.log("✅ Botão 'Adicionar' clicado imediatamente.");
    return true;
  }

  // Observa mutações para detectar quando o botão "Adicionar" aparece
  return new Promise(resolve => {
    const timeout = setTimeout(() => {
      observer.disconnect();
      console.warn("⏱️ Timeout: botão 'Adicionar' não apareceu.");
      resolve(false);
    }, timeoutMs);

    const observer = new MutationObserver(() => {
      const botao = encontrarBotaoAdicionar();
      if (botao) {
        clearTimeout(timeout);
        observer.disconnect();
        botao.click();
        console.log("✅ Botão 'Adicionar' clicado após observação.");
        resolve(true);
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });
  });
}


async function aguardarEClicarProximo(timeoutMs = 7000) {
  console.log("⏳ Aguardando botão 'Próximo' aparecer...");

  const encontrarBotaoProximo = () => {
    return [...document.querySelectorAll('button')]
      .find(btn =>
        btn.textContent.trim().toLowerCase() === "próximo" &&
        btn.offsetParent !== null
      );
  };

  const botaoInicial = encontrarBotaoProximo();
  if (botaoInicial) {
    botaoInicial.focus();
    botaoInicial.click();
    console.log("✅ Botão 'Próximo' clicado imediatamente.");
    return true;
  }

  // Se não encontrado, observar mudanças no DOM
  return new Promise(resolve => {
    const timeout = setTimeout(() => {
      observer.disconnect();
      console.warn("⏱️ Timeout: botão 'Próximo' não apareceu.");
      resolve(false);
    }, timeoutMs);

    const observer = new MutationObserver(() => {
      const botao = encontrarBotaoProximo();
      if (botao) {
        clearTimeout(timeout);
        observer.disconnect();
        botao.focus();
        botao.click();
        console.log("✅ Botão 'Próximo' clicado após observação.");
        resolve(true);
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });
  });
}

  
  

async function principal() {

  await clicarBotaoRegistroInicial(); // <-- Chama aqui primeiro
  await new Promise(r => setTimeout(r, 1000));
  
  await preencherCampos();
  await new Promise(r => setTimeout(r, 1000));

  fecharAnunciosECancelar();
  await new Promise(r => setTimeout(r, 3000));

  const saldo = lerSaldo();
  if (saldo !== null) console.log("💰 Saldo:", saldo);
  await new Promise(r => setTimeout(r, 3000));

  // await clicarBotoesDeRegistroSimples();
  // await new Promise(r => setTimeout(r, 3000));

  // await irParaPromocaoEMissao();
  // await new Promise(r => setTimeout(r, 3000));

//  await clicarReceberEProsseguir(); 
}


  window.executarAutomatizacao = automatizarDigitacao;
  window.digitarRapido = digitarInstantaneo;

  window.addEventListener("load", () => {

    const css = `
    *, *::before, *::after {
      animation: none !important;
      transition: none !important;
      scroll-behavior: auto !important;
    }
  `;
  const style = document.createElement('style');
  style.type = 'text/css';
  style.appendChild(document.createTextNode(css));
  document.head.appendChild(style);
  console.log("🚫 Animações CSS removidas");
  
    verificarErro403EAtualizar();
    principal();
  });

  const observer = new MutationObserver(() => {
    principal();
    monitorarPopupFechar();
  });
  

  observer.observe(document.body, { childList: true, subtree: true });

  const tecladoObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList') {
        const tecladoAdicionado = [...mutation.addedNodes].some(node => 
          node.nodeType === 1 && 
          (node.classList?.contains('ui-number-keyboard') || 
           node.querySelector?.('.ui-number-keyboard'))
        );
        
        if (tecladoAdicionado) {
          console.log("🎯 Teclado detectado! Executando em 200ms...");
          setTimeout(() => {
            principal();
          }, 200);
        }
      }
    });
  });

  tecladoObserver.observe(document.body, { 
    childList: true, 
    subtree: true 
  });

  window.debugTeclado = function() {
    console.log("🔍 DEBUG COMPLETO...");
    
    const todosTeclados = document.querySelectorAll('.ui-number-keyboard');
    console.log(`📱 Teclados encontrados: ${todosTeclados.length}`);
    
    todosTeclados.forEach((teclado, index) => {
      const estilo = window.getComputedStyle(teclado);
      const visivel = estilo.display !== 'none' && estilo.visibility !== 'hidden' && estilo.opacity !== '0';
      
      console.log(`\n🔸 Teclado ${index + 1} - ${visivel ? '✅ VISÍVEL' : '❌ OCULTO'}`);
      
      if (visivel) {
        const teclas = teclado.querySelectorAll('.ui-number-keyboard-key');
        console.log(`   📋 Teclas: ${teclas.length}`);
        
        const numeros = [];
        teclas.forEach(tecla => {
          const texto = tecla.textContent.trim();
          if (texto && !isNaN(texto)) {
            numeros.push(texto);
          }
        });
        console.log(`   🔢 Números disponíveis: [${numeros.join(', ')}]`);
      }
    });
  };

  window.testeRapido = async function() {
    console.log("🧪 TESTE RÁPIDO - Digitando 111112...");
    await digitarInstantaneo("111112");
  };

  console.log("🚀 Extensão carregada com digitação INSTANTÂNEA!");
  console.log("💡 Use: window.testeRapido() para testar manualmente");

})();
