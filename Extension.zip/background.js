chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    if (details.url.includes("gcaptcha4-hrc.gsensebot.com")) {
      console.log("🔒 Bloqueando:", details.url);
      return { cancel: true };
    }
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);
